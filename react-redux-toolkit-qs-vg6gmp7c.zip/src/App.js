import React from 'react';
import './style.css';
import TodoForm from './TodoForm';
import TodoList from './TodoList';

export default function App() {
  return (
    <div>
      <TodoForm />
      <TodoList />
    </div>
  );
}
