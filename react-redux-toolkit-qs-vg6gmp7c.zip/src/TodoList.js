import React,{useState} from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { toggleTask, deleteTask } from './store/todoSlice.js';

const TodoList = () => {
  const [filter, setFilter] = useState('All');
  const tasks = useSelector((state) => state.todos?.tasks);
  const dispatch = useDispatch();

  const filtredTasks = tasks?.filter((task) =>
    filter === 'All'
      ? true
      : filter === 'Completed'
      ? task.completed
      : !task.completed
  );

  return (
    <div>
      <div>
        <button onClick={() => setFilter('All')}>All</button>
        <button onClick={() => setFilter('Completed')}>Completed</button>
        <button onClick={() => setFilter('Pending')}>Pending</button>
      </div>
      <ul>
        {filtredTasks?.map((task) => (
          <li key={task.id}>
            <span
              style={{
                textDecoration: task.completed ? 'line-through' : 'none',
              }}
            >
              {task.text}
            </span>
            <button onClick={() => dispatch(deleteTask(task.id))}>
              Delete{' '}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
